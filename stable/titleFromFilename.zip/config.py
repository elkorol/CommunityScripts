# strip file extension from title
STRIP_EXT = True
